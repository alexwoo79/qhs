package main

// Product 定义商品结构体
type Product struct {
	Name     string
	Category string
	Price    float64
}

// 商品列表 Name,Category,Price
var Products = []Product{
	{"Kayak", "Watersports", 279.0},
	{"Lifejacket", "Watersports", 49.95},
	{"Soccer Ball", "Soccer", 19.5},
	{"Corner Flag", "Soccer", 34.95},
	{"Stadium", "Soccer", 79500.0},
	{"Thinking Cap", "Chess", 16.0},
	{"Unsteady Chair", "Chess", 75},
	{"Bling-Bling King", "Chess", 1200.0}}
