package main

import (
	"flag"
	"fmt"
	"os"
)

func main() {
	update := flag.Bool("update", false, "overwrite existing hugo content without prompt")
	dryRun := flag.Bool("dry-run", false, "show what would happen without writing files")
	flag.Parse()

	cfg, err := LoadConfig("config.json")
	if err != nil {
		fmt.Println("❌ load config failed:", err)
		os.Exit(1)
	}

	blogs, err := ScanBlogs(cfg)
	if err != nil {
		fmt.Println("❌ scan failed:", err)
		os.Exit(1)
	}

	for _, b := range blogs {
		if err := PublishBlogWithConfig(b, cfg, *update, *dryRun); err != nil {
			fmt.Println("❌", err)
		}
	}
}
