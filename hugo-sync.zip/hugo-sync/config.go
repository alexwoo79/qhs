package main

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
)

type Config struct {
	Obsidian struct {
		Vault string `json:"vault"`
	} `json:"obsidian"`

	Hugo struct {
		Site       string `json:"site"`
		ContentDir string `json:"content_dir"`
		Section    string `json:"blog_section"`
	} `json:"hugo"`

	Publish struct {
		RequireTag    string `json:"require_tag"`
		DefaultUpdate bool   `json:"default_update"`
	} `json:"publish"`
}

func DefaultConfig() *Config {
	cfg := &Config{}

	cfg.Obsidian.Vault = "/path/to/obsidian-vault"
	cfg.Hugo.Site = "/path/to/hugo-site"
	cfg.Hugo.ContentDir = "content"
	cfg.Hugo.Section = "blog"
	cfg.Publish.RequireTag = "blog"
	cfg.Publish.DefaultUpdate = false

	return cfg
}

func LoadConfig(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	var cfg Config
	if err := json.Unmarshal(data, &cfg); err != nil {
		return nil, err
	}

	if err := cfg.Validate(); err != nil {
		return nil, err
	}

	return &cfg, nil
}

func (c *Config) Validate() error {
	if c.Obsidian.Vault == "" {
		return errors.New("obsidian.vault is empty")
	}
	if c.Hugo.Site == "" {
		return errors.New("hugo.site is empty")
	}

	if !existsDir(c.Obsidian.Vault) {
		return errors.New("obsidian.vault not found: " + c.Obsidian.Vault)
	}
	if !existsDir(c.Hugo.Site) {
		return errors.New("hugo.site not found: " + c.Hugo.Site)
	}

	contentPath := filepath.Join(c.Hugo.Site, c.Hugo.ContentDir)
	if !existsDir(contentPath) {
		return errors.New("hugo content dir not found: " + contentPath)
	}

	return nil
}

func existsDir(p string) bool {
	info, err := os.Stat(p)
	return err == nil && info.IsDir()
}
