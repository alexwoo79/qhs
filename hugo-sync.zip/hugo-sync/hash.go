package main

import (
	"crypto/sha256"
	"encoding/hex"
	"io"
	"os"
	"path/filepath"
	"sort"
)

func HashObsidianDir(mdPath string) (string, error) {
	dir := filepath.Dir(mdPath)
	return hashDir(dir, func(name string) bool {
		return true // md + 所有附件
	})
}

func HashHugoBundle(bundleDir string) (string, error) {
	return hashDir(bundleDir, func(name string) bool {
		return name != ".DS_Store"
	})
}

func hashDir(dir string, filter func(string) bool) (string, error) {
	var files []string

	err := filepath.WalkDir(dir, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}

		name := filepath.Base(path)
		if !filter(name) {
			return nil
		}

		files = append(files, path)
		return nil
	})
	if err != nil {
		return "", err
	}

	sort.Strings(files)

	h := sha256.New()
	for _, f := range files {
		if err := hashFile(h, f); err != nil {
			return "", err
		}
	}

	return hex.EncodeToString(h.Sum(nil)), nil
}

func hashFile(h io.Writer, path string) error {
	file, err := os.Open(path)
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = io.Copy(h, file)
	return err
}
