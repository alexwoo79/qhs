package main

import (
	"os"
	"path/filepath"
	"strings"
)

/*
ScanBlogs 扫描 Obsidian Vault，返回所有需要发布的 markdown 文件路径
判定规则：
- front matter 中 tags 包含 blog
- 或正文中包含 #blog
*/

func ScanBlogs(cfg *Config) ([]string, error) {
	var blogs []string

	err := filepath.WalkDir(cfg.Obsidian.Vault, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}

		// 跳过隐藏目录
		if d.IsDir() {
			name := d.Name()
			if strings.HasPrefix(name, ".") {
				return filepath.SkipDir
			}
			return nil
		}

		if !strings.HasSuffix(strings.ToLower(d.Name()), ".md") {
			return nil
		}

		ok, err := isBlogMarkdown(path)
		if err != nil {
			return err
		}

		if ok {
			blogs = append(blogs, path)
		}

		return nil
	})

	return blogs, err
}

/* ---------- helpers ---------- */

func isBlogMarkdown(path string) (bool, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return false, err
	}

	content := string(data)

	// front matter tags
	if hasBlogTagInFrontMatter(content) {
		return true, nil
	}

	// fallback: #blog in content
	if strings.Contains(content, "#blog") {
		return true, nil
	}

	return false, nil
}

func hasBlogTagInFrontMatter(md string) bool {
	if !strings.HasPrefix(md, "---") {
		return false
	}

	parts := strings.SplitN(md, "---", 3)
	if len(parts) < 3 {
		return false
	}

	fm := parts[1]

	// 非严格解析，够用且安全
	if strings.Contains(fm, "blog") {
		return true
	}

	return false
}
