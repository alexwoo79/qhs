package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

/*
publishMarkdown
- Page Bundle 结构
- md → index.md
- 同目录附件 copy
- Obsidian tags → Hugo tags（全量同步）
*/

type FrontMatter map[string]interface{}

func publishMarkdown(src string, cfg *Config) error {
	content, err := os.ReadFile(src)
	if err != nil {
		return err
	}

	raw := string(content)

	// 解析 front matter
	fm, body := parseFrontMatter(raw)

	// 从正文中提取 #tags
	inlineTags := extractInlineTags(body)

	// 合并 tags（含 blog）
	mergeTags(fm, inlineTags)

	// 使用目录名作为 slug & fallback title
	srcDir := filepath.Dir(src)
	slug := filepath.Base(srcDir)

	// 补全 Hugo 必需字段
	ensureRequiredFrontMatter(fm, slug)

	targetDir := filepath.Join(
		cfg.Hugo.Site,
		cfg.Hugo.ContentDir,
		"blog",
		slug,
	)

	if err := os.MkdirAll(targetDir, 0755); err != nil {
		return err
	}

	if err := copyAttachmentsFromDir(src, targetDir); err != nil {
		return err
	}

	out := filepath.Join(targetDir, "index.md")
	return writeMarkdown(out, fm, body)
}

/* ---------- Front Matter ---------- */

func parseFrontMatter(md string) (FrontMatter, string) {
	if !strings.HasPrefix(md, "---") {
		return FrontMatter{}, md
	}

	parts := strings.SplitN(md, "---", 3)
	if len(parts) < 3 {
		return FrontMatter{}, md
	}

	fm := FrontMatter{}
	_ = yaml.Unmarshal([]byte(parts[1]), &fm)

	return fm, strings.TrimSpace(parts[2])
}

/*
mergeTags
- 合并 front matter tags + 正文 #tags
- 去重
- 保留 blog + 其他 tag
*/
func mergeTags(fm FrontMatter, extra []string) {
	tagSet := map[string]bool{}

	// front matter tags
	if raw, ok := fm["tags"]; ok {
		switch v := raw.(type) {
		case []interface{}:
			for _, t := range v {
				tagSet[fmt.Sprint(t)] = true
			}
		case []string:
			for _, t := range v {
				tagSet[t] = true
			}
		case string:
			tagSet[v] = true
		}
	}

	// inline tags
	for _, t := range extra {
		tagSet[t] = true
	}

	// 输出为 []string
	var tags []string
	for t := range tagSet {
		tags = append(tags, t)
	}

	if len(tags) > 0 {
		fm["tags"] = tags
	}
}

/* ---------- Required Hugo Fields ---------- */

func ensureRequiredFrontMatter(fm FrontMatter, fallbackTitle string) {
	if v, ok := fm["title"]; !ok || v == "" {
		fm["title"] = fallbackTitle
	}

	if _, ok := fm["date"]; !ok {
		fm["date"] = time.Now().Format(time.RFC3339)
	}

	if _, ok := fm["draft"]; !ok {
		fm["draft"] = false
	}
}

/* ---------- Inline Tags ---------- */

var tagRe = regexp.MustCompile(`(?m)#([a-zA-Z0-9_-]+)`)

func extractInlineTags(body string) []string {
	matches := tagRe.FindAllStringSubmatch(body, -1)

	var tags []string
	for _, m := range matches {
		if len(m) > 1 {
			tags = append(tags, m[1])
		}
	}
	return tags
}

/* ---------- Attachments ---------- */

func copyAttachmentsFromDir(mdPath, targetDir string) error {
	srcDir := filepath.Dir(mdPath)

	entries, err := os.ReadDir(srcDir)
	if err != nil {
		return err
	}

	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}

		name := entry.Name()
		if strings.HasSuffix(strings.ToLower(name), ".md") {
			continue
		}

		src := filepath.Join(srcDir, name)
		dst := filepath.Join(targetDir, name)

		if err := copyFile(src, dst); err != nil {
			return err
		}

		fmt.Println("📎 copied:", name)
	}

	return nil
}

/* ---------- IO ---------- */

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()

	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer out.Close()

	_, err = io.Copy(out, in)
	return err
}

func writeMarkdown(path string, fm FrontMatter, body string) error {
	data, err := yaml.Marshal(fm)
	if err != nil {
		return err
	}

	md := fmt.Sprintf(`---
%s
---

%s
`, strings.TrimSpace(string(data)), body)

	return os.WriteFile(path, []byte(md), 0644)
}

/*
PublishBlogWithConfig
- 检查 Hugo 中是否已存在
- 提示是否覆盖
*/
func PublishBlogWithConfig(
	src string,
	cfg *Config,
	force bool,
	dryRun bool,
) error {

	slug := filepath.Base(filepath.Dir(src))
	targetDir := filepath.Join(
		cfg.Hugo.Site,
		cfg.Hugo.ContentDir,
		"blog",
		slug,
	)

	srcHash, err := HashObsidianDir(src)
	if err != nil {
		return err
	}

	if exists(targetDir) {
		dstHash, err := HashHugoBundle(targetDir)
		if err == nil && srcHash == dstHash {
			fmt.Println("⏭ unchanged:", slug)
			return nil
		}

		if !force {
			ok, err := confirmOverwrite(slug)
			if err != nil {
				return err
			}
			if !ok {
				fmt.Println("⏭ skipped:", slug)
				return nil
			}
		}

		if dryRun {
			fmt.Println("♻️ will overwrite:", slug)
			return nil
		}

		fmt.Println("♻️ overwrite:", slug)
	} else {
		if dryRun {
			fmt.Println("🆕 will publish:", slug)
			return nil
		}
		fmt.Println("🆕 publish:", slug)
	}

	return publishMarkdown(src, cfg)
}

/* ---------- helpers ---------- */

func exists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}

func confirmOverwrite(slug string) (bool, error) {
	fmt.Printf("⚠️ Blog \"%s\" already exists. Overwrite? (y/N): ", slug)

	reader := bufio.NewReader(os.Stdin)
	input, err := reader.ReadString('\n')
	if err != nil {
		return false, err
	}

	input = strings.TrimSpace(strings.ToLower(input))
	return input == "y" || input == "yes", nil
}
