package main

import (
	"regexp"
	"strings"
)

var imgRe = regexp.MustCompile(`!\[[^\]]*]\(([^)]+)\)|!\[\[([^\]]+)\]\]`)

func ProcessMarkdown(md, title string) string {
	lines := strings.Split(md, "\n")

	if len(lines) > 0 {
		first := strings.TrimSpace(lines[0])
		if first == title || first == "# "+title {
			lines = lines[1:]
		}
	}

	body := strings.Join(lines, "\n")

	body = imgRe.ReplaceAllStringFunc(body, func(m string) string {
		sub := imgRe.FindStringSubmatch(m)
		if sub[1] != "" {
			return "![](" + cleanPath(sub[1]) + ")"
		}
		if sub[2] != "" {
			return "![](" + cleanPath(sub[2]) + ")"
		}
		return m
	})

	return body
}

func cleanPath(p string) string {
	return strings.TrimPrefix(p, "./")
}
