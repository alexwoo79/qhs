package main

import (
	"encoding/json"
	"fmt"
	"os"
)

func InitConfig(path string) error {
	if _, err := os.Stat(path); err == nil {
		return fmt.Errorf("config already exists: %s", path)
	}

	cfg := DefaultConfig()
	data, _ := json.MarshalIndent(cfg, "", "  ")

	if err := os.WriteFile(path, data, 0644); err != nil {
		return err
	}

	fmt.Println("✅ config.json created:", path)
	fmt.Println("👉 please edit paths before running publish")

	return nil
}
